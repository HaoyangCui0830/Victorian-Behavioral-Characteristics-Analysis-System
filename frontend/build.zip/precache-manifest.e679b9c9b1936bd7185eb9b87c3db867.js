self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba4513173cf882521a2fc492e7f479bf",
    "url": "/index.html"
  },
  {
    "revision": "bf59ac3610bdc6819a9d",
    "url": "/static/css/2.de424728.chunk.css"
  },
  {
    "revision": "c58c8172e6e0f7fdebc4",
    "url": "/static/css/main.514ad195.chunk.css"
  },
  {
    "revision": "bf59ac3610bdc6819a9d",
    "url": "/static/js/2.0ce094b1.chunk.js"
  },
  {
    "revision": "1f343f3b00bd42841cd23cdb6e2b08ec",
    "url": "/static/js/2.0ce094b1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c58c8172e6e0f7fdebc4",
    "url": "/static/js/main.0015208f.chunk.js"
  },
  {
    "revision": "055e94f6602794288cc3",
    "url": "/static/js/runtime-main.1f1f19a3.js"
  }
]);